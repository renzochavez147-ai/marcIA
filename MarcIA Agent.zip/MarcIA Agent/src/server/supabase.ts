import { createClient } from '@supabase/supabase-js'
import { env } from '~/server/env'

// Create a Supabase client with fallback handling
export const supabase = (() => {
  if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY) {
    console.warn('⚠️  Supabase credentials not found. Creating a mock client for demo mode.');
    
    // Return a mock client that won't crash but will return empty results
    return {
      from: () => ({
        select: () => Promise.resolve({ data: [], error: new Error('Supabase not configured') }),
        insert: () => Promise.resolve({ data: null, error: new Error('Supabase not configured') }),
        update: () => Promise.resolve({ data: null, error: new Error('Supabase not configured') }),
        delete: () => Promise.resolve({ data: null, error: new Error('Supabase not configured') }),
      }),
    } as any;
  }
  
  return createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY);
})();
