import { Client } from "minio";
import { env } from "./env";
import { getBaseUrl } from "./utils/base-url";

export const minioBaseUrl = getBaseUrl({ port: 9000 });

// Create MinIO client with error handling
export const minioClient = (() => {
  if (!env.ADMIN_PASSWORD) {
    console.warn('⚠️  MinIO admin password not found. File storage will be limited.');
    // Return a mock client that won't crash but will return errors
    return {
      putObject: () => Promise.reject(new Error('MinIO not configured')),
      getObject: () => Promise.reject(new Error('MinIO not configured')),
      removeObject: () => Promise.reject(new Error('MinIO not configured')),
      listObjects: () => Promise.reject(new Error('MinIO not configured')),
    } as any;
  }
  
  return new Client({
    endPoint: minioBaseUrl.split("://")[1]!,
    useSSL: minioBaseUrl.startsWith("https://"),
    accessKey: "admin",
    secretKey: env.ADMIN_PASSWORD,
  });
})();
