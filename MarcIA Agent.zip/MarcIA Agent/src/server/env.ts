import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production"]).default("development"),
  BASE_URL: z.string().optional(),
  BASE_URL_OTHER_PORT: z.string().optional(),
  ADMIN_PASSWORD: z.string().optional(),
  OPENROUTER_API_KEY: z.string().optional(),
  SUPABASE_URL: z.string().optional(),
  SUPABASE_ANON_KEY: z.string().optional(),
});

// Parse with better error handling
let env: z.infer<typeof envSchema>;

try {
  env = envSchema.parse(process.env);
} catch (error) {
  console.warn("Warning: Some environment variables are missing. Using defaults where possible.");
  console.warn("Error details:", error);
  
  // Provide a fallback env object with defaults
  env = {
    NODE_ENV: (process.env.NODE_ENV as "development" | "production") || "development",
    BASE_URL: process.env.BASE_URL,
    BASE_URL_OTHER_PORT: process.env.BASE_URL_OTHER_PORT,
    ADMIN_PASSWORD: process.env.ADMIN_PASSWORD,
    OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY,
    SUPABASE_URL: process.env.SUPABASE_URL,
    SUPABASE_ANON_KEY: process.env.SUPABASE_ANON_KEY,
  };
}

export { env };
