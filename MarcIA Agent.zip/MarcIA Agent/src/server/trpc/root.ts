import {
  createCallerFactory,
  createTRPCRouter,
} from "~/server/trpc/main";
import { validateQuery } from "~/server/trpc/procedures/validateQuery";
import { fetchCustomerData } from "~/server/trpc/procedures/fetchCustomerData";
import { generateMarketing } from "~/server/trpc/procedures/generateMarketing";
import { getDemoData } from "~/server/trpc/procedures/demoData";

export const appRouter = createTRPCRouter({
  validateQuery,
  fetchCustomerData,
  generateMarketing,
  getDemoData,
});

export type AppRouter = typeof appRouter;

export const createCaller = createCallerFactory(appRouter);
