import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { baseProcedure } from "~/server/trpc/main";
import { generateObject } from "ai";
import { createOpenRouter } from "@openrouter/ai-sdk-provider";
import { env } from "~/server/env";

// Create OpenRouter client with error handling
const openrouter = (() => {
  if (!env.OPENROUTER_API_KEY) {
    console.warn('⚠️  OpenRouter API key not found. Query validation will be limited.');
    return null;
  }
  return createOpenRouter({
    apiKey: env.OPENROUTER_API_KEY,
  });
})();

const supabaseQuerySchema = z.object({
  table: z.string().describe("The main table to query from (e.g., 'customers', 'orders', 'products')"),
  select: z.array(z.string()).describe("Columns to select from the table"),
  filters: z.array(z.object({
    column: z.string(),
    operator: z.enum(["eq", "neq", "gt", "gte", "lt", "lte", "like", "ilike", "in", "contains"]),
    value: z.union([z.string(), z.number(), z.array(z.string())]),
  })).optional().describe("Filter conditions for the query"),
  joins: z.array(z.object({
    table: z.string(),
    on: z.string().describe("Join condition like 'customers.id=orders.customer_id'"),
    type: z.enum(["inner", "left", "right"]).default("left"),
  })).optional().describe("Tables to join with"),
  orderBy: z.object({
    column: z.string(),
    ascending: z.boolean().default(false),
  }).optional().describe("How to sort the results"),
  limit: z.number().optional().describe("Maximum number of records to return"),
});

export const validateQuery = baseProcedure
  .input(z.object({ 
    naturalLanguageQuery: z.string().min(1, "Query cannot be empty") 
  }))
  .mutation(async ({ input }) => {
    try {
      if (!openrouter) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "AI query validation is not available. Please configure the OpenRouter API key.",
        });
      }

      const { object } = await generateObject({
        model: openrouter("openai/gpt-4o"),
        schema: z.object({
          query: supabaseQuerySchema,
          interpretation: z.string().describe("A human-readable interpretation of what the query will do"),
          confidence: z.number().min(0).max(1).describe("Confidence level in the query interpretation (0-1)"),
        }),
        prompt: `You are an expert at converting natural language queries into structured database queries for a marketing database.

The database contains these main tables:
- customers: id, name, email, location, created_at, status
- orders: id, customer_id, product_id, amount, order_date, status
- products: id, name, category, price, created_at

Convert this natural language query into a structured Supabase query:
"${input.naturalLanguageQuery}"

Focus on:
1. Identifying the main table to query
2. Determining what columns to select
3. Creating appropriate filters based on conditions mentioned
4. Adding joins if multiple tables are referenced
5. Setting reasonable limits if not specified

Make sure the query is optimized for marketing segmentation purposes.`,
      });

      if (object.confidence < 0.7) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Query is too ambiguous. Please provide more specific criteria for your customer segment.",
        });
      }

      return {
        structuredQuery: object.query,
        interpretation: object.interpretation,
        confidence: object.confidence,
      };
    } catch (error) {
      if (error instanceof TRPCError) {
        throw error;
      }
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to validate and structure the query. Please try rephrasing your request.",
      });
    }
  });
