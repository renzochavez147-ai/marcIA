import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { baseProcedure } from "~/server/trpc/main";
import { supabase } from "~/server/supabase";

const structuredQuerySchema = z.object({
  table: z.string(),
  select: z.array(z.string()),
  filters: z.array(z.object({
    column: z.string(),
    operator: z.enum(["eq", "neq", "gt", "gte", "lt", "lte", "like", "ilike", "in", "contains"]),
    value: z.union([z.string(), z.number(), z.array(z.string())]),
  })).optional(),
  joins: z.array(z.object({
    table: z.string(),
    on: z.string(),
    type: z.enum(["inner", "left", "right"]).default("left"),
  })).optional(),
  orderBy: z.object({
    column: z.string(),
    ascending: z.boolean().default(false),
  }).optional(),
  limit: z.number().optional(),
});

export const fetchCustomerData = baseProcedure
  .input(z.object({
    structuredQuery: structuredQuerySchema,
    originalQuery: z.string().optional(),
  }))
  .mutation(async ({ input }) => {
    try {
      const { structuredQuery } = input;
      
      // Start building the query
      let query = supabase
        .from(structuredQuery.table)
        .select(structuredQuery.select.join(', '));

      // Apply filters
      if (structuredQuery.filters) {
        for (const filter of structuredQuery.filters) {
          switch (filter.operator) {
            case 'eq':
              query = query.eq(filter.column, filter.value);
              break;
            case 'neq':
              query = query.neq(filter.column, filter.value);
              break;
            case 'gt':
              query = query.gt(filter.column, filter.value);
              break;
            case 'gte':
              query = query.gte(filter.column, filter.value);
              break;
            case 'lt':
              query = query.lt(filter.column, filter.value);
              break;
            case 'lte':
              query = query.lte(filter.column, filter.value);
              break;
            case 'like':
              query = query.like(filter.column, filter.value as string);
              break;
            case 'ilike':
              query = query.ilike(filter.column, filter.value as string);
              break;
            case 'in':
              query = query.in(filter.column, filter.value as string[]);
              break;
            case 'contains':
              query = query.contains(filter.column, filter.value);
              break;
          }
        }
      }

      // Apply ordering
      if (structuredQuery.orderBy) {
        query = query.order(structuredQuery.orderBy.column, { 
          ascending: structuredQuery.orderBy.ascending 
        });
      }

      // Apply limit (default to 1000 for performance)
      const limit = structuredQuery.limit || 1000;
      query = query.limit(limit);

      // Execute the query
      const { data, error } = await query;

      if (error) {
        console.log("Supabase query failed, falling back to demo data:", error.message);
        return getDemoDataFallback(input.originalQuery || "demo query");
      }

      if (!data || data.length === 0) {
        console.log("No data found in Supabase, falling back to demo data");
        return getDemoDataFallback(input.originalQuery || "demo query");
      }

      return {
        customers: data,
        count: data.length,
        message: `Found ${data.length} customer${data.length === 1 ? '' : 's'} matching your criteria.`,
        isDemo: false,
      };
    } catch (error) {
      console.log("Database error, falling back to demo data:", error);
      return getDemoDataFallback(input.originalQuery || "demo query");
    }
  });

function getDemoDataFallback(query: string) {
  // Demo customer data
  const sampleCustomers = [
    {
      id: "1",
      name: "María García",
      email: "maria.garcia@email.com",
      location: "Lima",
      created_at: "2024-01-15T10:30:00Z",
      status: "active",
      total_spent: 450.00,
      last_order_date: "2024-01-20T14:22:00Z",
      order_count: 3
    },
    {
      id: "2", 
      name: "Carlos Rodriguez",
      email: "carlos.rodriguez@email.com",
      location: "Lima",
      created_at: "2024-01-10T09:15:00Z",
      status: "active",
      total_spent: 320.50,
      last_order_date: "2024-01-18T16:45:00Z",
      order_count: 2
    },
    {
      id: "3",
      name: "Ana Fernández",
      email: "ana.fernandez@email.com", 
      location: "Cusco",
      created_at: "2023-12-20T11:20:00Z",
      status: "active",
      total_spent: 780.25,
      last_order_date: "2024-01-22T13:10:00Z",
      order_count: 5
    },
    {
      id: "4",
      name: "Luis Mendoza",
      email: "luis.mendoza@email.com",
      location: "Lima", 
      created_at: "2024-01-05T08:45:00Z",
      status: "active",
      total_spent: 125.75,
      last_order_date: "2024-01-12T12:30:00Z",
      order_count: 1
    },
    {
      id: "5",
      name: "Isabella Torres",
      email: "isabella.torres@email.com",
      location: "Arequipa",
      created_at: "2023-11-30T15:10:00Z", 
      status: "active",
      total_spent: 920.00,
      last_order_date: "2024-01-25T10:15:00Z",
      order_count: 7
    },
    {
      id: "6",
      name: "Diego Vargas",
      email: "diego.vargas@email.com",
      location: "Lima",
      created_at: "2024-01-08T14:25:00Z",
      status: "active", 
      total_spent: 275.30,
      last_order_date: "2024-01-19T17:20:00Z",
      order_count: 2
    }
  ];

  // Simple filtering logic for demo purposes
  let filteredCustomers = [...sampleCustomers];
  
  const queryLower = query.toLowerCase();
  
  // Filter by location if mentioned
  if (queryLower.includes('lima')) {
    filteredCustomers = filteredCustomers.filter(c => c.location.toLowerCase() === 'lima');
  } else if (queryLower.includes('cusco')) {
    filteredCustomers = filteredCustomers.filter(c => c.location.toLowerCase() === 'cusco');
  } else if (queryLower.includes('arequipa')) {
    filteredCustomers = filteredCustomers.filter(c => c.location.toLowerCase() === 'arequipa');
  }
  
  // Filter by spending if mentioned
  if (queryLower.includes('spent more than') || queryLower.includes('$100')) {
    const amount = queryLower.includes('$100') ? 100 : 200;
    filteredCustomers = filteredCustomers.filter(c => c.total_spent > amount);
  }
  
  return {
    customers: filteredCustomers,
    count: filteredCustomers.length,
    message: `Found ${filteredCustomers.length} customer${filteredCustomers.length === 1 ? '' : 's'} matching your criteria (demo data).`,
    isDemo: true,
  };
}
