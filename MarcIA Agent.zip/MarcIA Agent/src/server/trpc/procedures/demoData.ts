import { z } from "zod";
import { baseProcedure } from "~/server/trpc/main";

const sampleCustomers = [
  {
    id: "1",
    name: "María García",
    email: "maria.garcia@email.com",
    location: "Lima",
    created_at: "2024-01-15T10:30:00Z",
    status: "active",
    total_spent: 450.00,
    last_order_date: "2024-01-20T14:22:00Z",
    order_count: 3
  },
  {
    id: "2", 
    name: "Carlos Rodriguez",
    email: "carlos.rodriguez@email.com",
    location: "Lima",
    created_at: "2024-01-10T09:15:00Z",
    status: "active",
    total_spent: 320.50,
    last_order_date: "2024-01-18T16:45:00Z",
    order_count: 2
  },
  {
    id: "3",
    name: "Ana Fernández",
    email: "ana.fernandez@email.com", 
    location: "Cusco",
    created_at: "2023-12-20T11:20:00Z",
    status: "active",
    total_spent: 780.25,
    last_order_date: "2024-01-22T13:10:00Z",
    order_count: 5
  },
  {
    id: "4",
    name: "Luis Mendoza",
    email: "luis.mendoza@email.com",
    location: "Lima", 
    created_at: "2024-01-05T08:45:00Z",
    status: "active",
    total_spent: 125.75,
    last_order_date: "2024-01-12T12:30:00Z",
    order_count: 1
  },
  {
    id: "5",
    name: "Isabella Torres",
    email: "isabella.torres@email.com",
    location: "Arequipa",
    created_at: "2023-11-30T15:10:00Z", 
    status: "active",
    total_spent: 920.00,
    last_order_date: "2024-01-25T10:15:00Z",
    order_count: 7
  },
  {
    id: "6",
    name: "Diego Vargas",
    email: "diego.vargas@email.com",
    location: "Lima",
    created_at: "2024-01-08T14:25:00Z",
    status: "active", 
    total_spent: 275.30,
    last_order_date: "2024-01-19T17:20:00Z",
    order_count: 2
  },
  {
    id: "7",
    name: "Sofia Herrera",
    email: "sofia.herrera@email.com",
    location: "Trujillo",
    created_at: "2023-12-15T12:40:00Z",
    status: "active",
    total_spent: 650.80,
    last_order_date: "2024-01-21T09:35:00Z", 
    order_count: 4
  },
  {
    id: "8",
    name: "Roberto Silva",
    email: "roberto.silva@email.com",
    location: "Lima",
    created_at: "2024-01-12T16:50:00Z",
    status: "active",
    total_spent: 180.45,
    last_order_date: "2024-01-24T11:25:00Z",
    order_count: 1
  }
];

export const getDemoData = baseProcedure
  .input(z.object({
    query: z.string(),
    filters: z.record(z.any()).optional(),
  }))
  .query(({ input }) => {
    // Simple filtering logic for demo purposes
    let filteredCustomers = [...sampleCustomers];
    
    const queryLower = input.query.toLowerCase();
    
    // Filter by location if mentioned
    if (queryLower.includes('lima')) {
      filteredCustomers = filteredCustomers.filter(c => c.location.toLowerCase() === 'lima');
    } else if (queryLower.includes('cusco')) {
      filteredCustomers = filteredCustomers.filter(c => c.location.toLowerCase() === 'cusco');
    } else if (queryLower.includes('arequipa')) {
      filteredCustomers = filteredCustomers.filter(c => c.location.toLowerCase() === 'arequipa');
    }
    
    // Filter by spending if mentioned
    if (queryLower.includes('spent more than') || queryLower.includes('$100')) {
      const amount = queryLower.includes('$100') ? 100 : 200;
      filteredCustomers = filteredCustomers.filter(c => c.total_spent > amount);
    }
    
    // Filter by recent orders
    if (queryLower.includes('last month') || queryLower.includes('recent')) {
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
      filteredCustomers = filteredCustomers.filter(c => 
        new Date(c.last_order_date) > oneMonthAgo
      );
    }
    
    return {
      customers: filteredCustomers,
      count: filteredCustomers.length,
      message: `Found ${filteredCustomers.length} customer${filteredCustomers.length === 1 ? '' : 's'} matching your criteria (demo data).`,
      isDemo: true,
    };
  });
