import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { baseProcedure } from "~/server/trpc/main";
import { generateText } from "ai";
import { createOpenRouter } from "@openrouter/ai-sdk-provider";
import { env } from "~/server/env";

// Create OpenRouter client with error handling
const openrouter = (() => {
  if (!env.OPENROUTER_API_KEY) {
    console.warn('⚠️  OpenRouter API key not found. AI features will be limited.');
    return null;
  }
  return createOpenRouter({
    apiKey: env.OPENROUTER_API_KEY,
  });
})();

function jsonToCsv(data: any[]): string {
  if (!data || data.length === 0) return '';
  
  const headers = Object.keys(data[0]);
  const csvHeaders = headers.join(',');
  
  const csvRows = data.map(row => 
    headers.map(header => {
      const value = row[header];
      // Escape commas and quotes in CSV values
      if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
        return `"${value.replace(/"/g, '""')}"`;
      }
      return value;
    }).join(',')
  );
  
  return [csvHeaders, ...csvRows].join('\n');
}

export const generateMarketing = baseProcedure
  .input(z.object({
    customers: z.array(z.record(z.any())),
    query: z.string(),
    interpretation: z.string(),
  }))
  .mutation(async ({ input }) => {
    try {
      const { customers, query, interpretation } = input;

      if (!customers || customers.length === 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "No customer data provided for marketing generation.",
        });
      }

      if (!openrouter) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "AI marketing generation is not available. Please configure the OpenRouter API key.",
        });
      }

      // Generate CSV
      const csvData = jsonToCsv(customers);

      // Analyze customer data for insights
      const customerSample = customers.slice(0, 5); // Sample for analysis
      const totalCustomers = customers.length;

      // Generate HTML email template
      const { text: emailHtml } = await generateText({
        model: openrouter("openai/gpt-4o"),
        system: "You are an expert email marketing specialist. Create engaging, personalized HTML email templates that drive conversions.",
        prompt: `Create a professional HTML email template for a marketing campaign targeting the following customer segment:

Query: ${query}
Interpretation: ${interpretation}
Total customers: ${totalCustomers}

Sample customer data:
${JSON.stringify(customerSample, null, 2)}

Requirements:
1. Create a complete HTML email with inline CSS
2. Include a compelling subject line suggestion
3. Personalize the content based on customer insights
4. Include a clear call-to-action
5. Make it mobile-responsive
6. Use professional marketing email best practices
7. Include placeholder merge fields like {{customer_name}}, {{customer_email}} where appropriate

Return only the HTML code for the email template.`,
      });

      // Generate text summary
      const { text: summary } = await generateText({
        model: openrouter("openai/gpt-4o"),
        system: "You are a marketing analyst providing clear, actionable insights.",
        prompt: `Analyze this customer segmentation and provide a concise marketing summary:

Original Query: ${query}
Query Interpretation: ${interpretation}
Total Customers Found: ${totalCustomers}

Sample Customer Data:
${JSON.stringify(customerSample, null, 2)}

Provide:
1. Key insights about this customer segment
2. Recommended marketing strategies
3. Potential campaign ideas
4. Expected engagement rates or outcomes
5. Next steps for the marketing team

Keep it professional, actionable, and under 300 words.`,
      });

      return {
        csvData,
        emailHtml,
        summary,
        customerCount: totalCustomers,
        success: true,
      };
    } catch (error) {
      if (error instanceof TRPCError) {
        throw error;
      }
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to generate marketing materials. Please try again.",
      });
    }
  });
