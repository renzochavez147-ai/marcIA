import { createFileRoute } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { useTRPC } from "~/trpc/react";
import { useMutation } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { 
  Sparkles, 
  Users, 
  Mail, 
  Download, 
  Search, 
  TrendingUp, 
  Target,
  Zap,
  BarChart3,
  FileText
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Home,
});

const querySchema = z.object({
  query: z.string().min(10, "Please provide a more detailed query (at least 10 characters)"),
});

type QueryForm = z.infer<typeof querySchema>;

interface CustomerData {
  customers: any[];
  count: number;
  message: string;
  isDemo?: boolean;
}

interface MarketingResults {
  csvData: string;
  emailHtml: string;
  summary: string;
  customerCount: number;
  success: boolean;
}

function Home() {
  const [results, setResults] = useState<{
    customerData?: CustomerData;
    marketing?: MarketingResults;
    interpretation?: string;
  }>({});
  const [isProcessing, setIsProcessing] = useState(false);

  const trpc = useTRPC();
  const validateMutation = useMutation(trpc.validateQuery.mutationOptions());
  const fetchDataMutation = useMutation(trpc.fetchCustomerData.mutationOptions());
  const generateMarketingMutation = useMutation(trpc.generateMarketing.mutationOptions());

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<QueryForm>({
    resolver: zodResolver(querySchema),
  });

  const onSubmit = async (data: QueryForm) => {
    setIsProcessing(true);
    setResults({});

    try {
      // Step 1: Validate and structure the query
      toast.loading("🧠 Analyzing your query...", { id: "processing" });
      const validation = await validateMutation.mutateAsync({
        naturalLanguageQuery: data.query,
      });

      toast.loading("📊 Fetching customer data...", { id: "processing" });
      
      // Step 2: Fetch customer data
      const customerData = await fetchDataMutation.mutateAsync({
        structuredQuery: validation.structuredQuery,
        originalQuery: data.query,
      });

      if (customerData.customers.length === 0) {
        toast.error("No customers found matching your criteria. Try adjusting your query.", { id: "processing" });
        setIsProcessing(false);
        return;
      }

      toast.loading("✨ Generating marketing materials...", { id: "processing" });

      // Step 3: Generate marketing materials
      const marketing = await generateMarketingMutation.mutateAsync({
        customers: customerData.customers,
        query: data.query,
        interpretation: validation.interpretation,
      });

      setResults({
        customerData,
        marketing,
        interpretation: validation.interpretation,
      });

      toast.success(`🎉 Campaign ready! Found ${customerData.count} customers`, { id: "processing" });
    } catch (error: any) {
      toast.error(error.message || "Something went wrong. Please try again.", { id: "processing" });
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadCSV = () => {
    if (!results.marketing?.csvData) return;
    
    const blob = new Blob([results.marketing.csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'customer-segment.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success("CSV downloaded successfully!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-white/20 backdrop-blur-sm rounded-2xl">
                <Sparkles className="h-12 w-12 text-white" />
              </div>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
              marc<span className="text-cyan-300">IA</span>
            </h1>
            <p className="text-xl md:text-2xl text-indigo-100 mb-8 max-w-3xl mx-auto leading-relaxed">
              AI-Powered Marketing Intelligence Platform
            </p>
            <p className="text-lg text-indigo-200 max-w-2xl mx-auto">
              Transform natural language queries into targeted customer segments and personalized campaigns
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent"></div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Query Form */}
        <div className="mb-16">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
              <div className="p-8 md:p-12">
                <div className="text-center mb-8">
                  <div className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full text-white font-semibold mb-6">
                    <Target className="h-5 w-5" />
                    Define Your Target Segment
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    Describe Your Ideal Customer
                  </h2>
                  <p className="text-gray-600 text-lg">
                    Use natural language to define your customer segment and get actionable insights
                  </p>
                </div>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div>
                    <label htmlFor="query" className="block text-sm font-semibold text-gray-700 mb-3">
                      Customer Segment Query
                    </label>
                    <div className="relative">
                      <Search className="absolute left-4 top-4 h-6 w-6 text-gray-400" />
                      <textarea
                        id="query"
                        rows={4}
                        placeholder="e.g., I want to target customers in Lima who bought product X in the last month and spent more than $100"
                        {...register("query")}
                        className="w-full pl-14 pr-4 py-4 text-lg border-2 border-gray-200 rounded-2xl focus:border-indigo-500 focus:ring-0 transition-colors resize-none"
                      />
                    </div>
                    {errors.query && (
                      <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                        <span className="w-1 h-1 bg-red-600 rounded-full"></span>
                        {errors.query.message}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 px-8 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200 disabled:opacity-50 disabled:transform-none disabled:hover:shadow-lg flex items-center justify-center gap-3"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent"></div>
                        Processing...
                      </>
                    ) : (
                      <>
                        <Zap className="h-6 w-6" />
                        Generate Campaign
                      </>
                    )}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>

        {/* Results Section */}
        {(results.customerData || results.marketing) && (
          <div className="space-y-8">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-100 rounded-xl">
                    <Users className="h-8 w-8 text-indigo-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Customers Found</p>
                    <p className="text-3xl font-bold text-gray-900">{results.customerData?.count || 0}</p>
                    {results.customerData?.isDemo && (
                      <p className="text-xs text-blue-600 font-medium">Demo Data</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-green-100 rounded-xl">
                    <TrendingUp className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Campaign Ready</p>
                    <p className="text-3xl font-bold text-gray-900">
                      {results.marketing ? "✓" : "⏳"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-purple-100 rounded-xl">
                    <BarChart3 className="h-8 w-8 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Segment Quality</p>
                    <p className="text-3xl font-bold text-gray-900">High</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Interpretation */}
            {results.interpretation && (
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-100">
                <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-3">
                  <FileText className="h-6 w-6 text-indigo-600" />
                  Query Interpretation
                </h3>
                <p className="text-gray-700 text-lg leading-relaxed">{results.interpretation}</p>
              </div>
            )}

            {/* Marketing Materials */}
            {results.marketing && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* CSV Download */}
                <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-semibold text-gray-900 flex items-center gap-3">
                      <Download className="h-6 w-6 text-green-600" />
                      Customer Data
                    </h3>
                    <button
                      onClick={downloadCSV}
                      className="bg-green-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center gap-2"
                    >
                      <Download className="h-5 w-5" />
                      Download CSV
                    </button>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Export your customer segment data as a CSV file for use in other marketing tools.
                  </p>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <p className="text-sm text-gray-500 mb-2">Preview:</p>
                    <pre className="text-xs text-gray-700 overflow-x-auto">
                      {results.marketing.csvData.split('\n').slice(0, 3).join('\n')}
                      {results.marketing.csvData.split('\n').length > 3 && '\n...'}
                    </pre>
                  </div>
                </div>

                {/* Email Template */}
                <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-3">
                    <Mail className="h-6 w-6 text-blue-600" />
                    Email Template
                  </h3>
                  <div className="bg-gray-50 rounded-xl p-4 max-h-96 overflow-y-auto">
                    <div 
                      className="prose prose-sm max-w-none"
                      dangerouslySetInnerHTML={{ __html: results.marketing.emailHtml }}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Marketing Summary */}
            {results.marketing?.summary && (
              <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-3">
                  <Sparkles className="h-6 w-6 text-purple-600" />
                  Marketing Insights & Recommendations
                </h3>
                <div className="prose prose-lg max-w-none text-gray-700">
                  {results.marketing.summary.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4 leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Features Section */}
        {!results.customerData && !isProcessing && (
          <div className="mt-24">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Powerful AI-Driven Marketing
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Transform your marketing strategy with intelligent customer segmentation and automated campaign generation
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="inline-flex p-4 bg-indigo-100 rounded-2xl mb-6">
                  <Users className="h-8 w-8 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Smart Segmentation</h3>
                <p className="text-gray-600 leading-relaxed">
                  Use natural language to define complex customer segments with AI-powered query interpretation
                </p>
              </div>

              <div className="text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="inline-flex p-4 bg-green-100 rounded-2xl mb-6">
                  <Mail className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Automated Campaigns</h3>
                <p className="text-gray-600 leading-relaxed">
                  Generate personalized email templates and marketing materials tailored to your audience
                </p>
              </div>

              <div className="text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="inline-flex p-4 bg-purple-100 rounded-2xl mb-6">
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Actionable Insights</h3>
                <p className="text-gray-600 leading-relaxed">
                  Get detailed analytics and recommendations to optimize your marketing performance
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
