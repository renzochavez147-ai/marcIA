# marcIA - AI-Powered Marketing Intelligence Platform

![marcIA Logo](https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=200&fit=crop&crop=center)

**marcIA** is an advanced AI-powered marketing application that enables non-technical users to define market segments using natural language, retrieve targeted customer data, and generate personalized email campaigns automatically.

## 🌟 Features

### 🧠 AI-Powered Agents
- **Validator Agent**: Converts natural language queries into structured database queries
- **Data Agent**: Executes secure queries against Supabase database
- **Marketer Agent**: Generates personalized campaigns, insights, and marketing materials

### 🎨 Beautiful User Interface
- Pixel-perfect, responsive design with "wow effect"
- Gradient backgrounds and modern UI components
- Real-time processing feedback with toast notifications
- Interactive results visualization

### 📊 Marketing Intelligence
- Natural language customer segmentation
- Automated CSV export for customer data
- AI-generated HTML email templates
- Marketing insights and recommendations
- Campaign performance predictions

## 🏗️ Architecture

### Data Flow
1. **User Input**: Natural language query (e.g., "customers in Lima who spent >$100 last month")
2. **Validator Agent**: Translates query into structured Supabase format
3. **Data Agent**: Executes query and retrieves customer data
4. **Marketer Agent**: Generates CSV, email template, and marketing insights
5. **Final Delivery**: Downloadable materials and campaign recommendations

### Technology Stack
- **Frontend**: React, TanStack Router, Tailwind CSS
- **Backend**: tRPC, Node.js
- **Database**: Supabase (PostgreSQL)
- **AI**: OpenRouter API with GPT-4o
- **Forms**: React Hook Form with Zod validation
- **Notifications**: React Hot Toast

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and pnpm
- Supabase account and project
- OpenRouter API key

### Environment Variables
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
OPENROUTER_API_KEY=sk-or-v1-your-key
```

### Database Schema
Create these tables in your Supabase project:

```sql
-- Customers table
CREATE TABLE customers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  location TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT DEFAULT 'active'
);

-- Products table
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  price NUMERIC(10,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Orders table
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID REFERENCES customers(id),
  product_id UUID REFERENCES products(id),
  amount NUMERIC(10,2),
  order_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT DEFAULT 'completed'
);
```

### Installation
```bash
# Clone the repository
git clone <repository-url>
cd marcia-agent

# Install dependencies
pnpm install

# Set up environment variables
cp .env.example .env
# Edit .env with your credentials

# Start development server
pnpm dev
```

## 📝 Usage Examples

### Example Queries
- "I want to target customers in Lima who bought product X in the last month"
- "Find customers who spent more than $100 and are located in Peru"
- "Show me active customers from Cusco with recent orders"
- "Get customers who purchased electronics in the last 3 months"

### Expected Outputs
- **Customer List**: Filtered customer data based on your criteria
- **CSV Export**: Downloadable customer data file
- **Email Template**: AI-generated HTML email for the segment
- **Marketing Insights**: Actionable recommendations and strategies

## 🎯 Demo Mode

The application includes a demo mode with sample customer data that activates when:
- Supabase tables don't exist
- Database queries return no results
- Connection to Supabase fails

Demo data includes realistic customer profiles from Lima, Cusco, and Arequipa with various purchase patterns.

## 🔧 API Endpoints

### tRPC Procedures
- `validateQuery`: Converts natural language to structured query
- `fetchCustomerData`: Retrieves customer data from database
- `generateMarketing`: Creates marketing materials and insights
- `getDemoData`: Provides sample data for testing

## 🎨 Design System

### Color Palette
- Primary: Indigo gradients (#4F46E5 to #7C3AED)
- Secondary: Cyan accents (#06B6D4)
- Success: Green (#059669)
- Background: Gradient from indigo-50 to cyan-50

### Components
- Rounded corners (2xl = 16px)
- Shadow system (lg, xl, 2xl)
- Hover animations and transforms
- Responsive breakpoints (sm, md, lg, xl)

## 🔐 Security

- Environment variables for API keys
- Supabase Row Level Security (RLS) support
- Input validation with Zod schemas
- tRPC error handling and type safety

## 🚀 Deployment

The application is designed to work in managed runtime environments with:
- Automatic dependency installation
- Environment variable management
- Database migrations (if using Prisma)
- Static asset optimization

## 📊 Environment Variables

| Variable | Current Value | Required to Change? |
|----------|---------------|-------------------|
| `SUPABASE_URL` | https://wivqrepkhblufbxtaduc.supabase.co | No - works with demo mode |
| `SUPABASE_ANON_KEY` | [provided key] | No - works with demo mode |
| `OPENROUTER_API_KEY` | [provided key] | No - current key works |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with demo data
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

---

**Built with ❤️ using AI-powered development**
