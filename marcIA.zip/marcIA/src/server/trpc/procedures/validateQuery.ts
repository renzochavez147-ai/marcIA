import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { baseProcedure } from "~/server/trpc/main";
import { generateObject } from "ai";
import { createOpenRouter } from "@openrouter/ai-sdk-provider";

const openrouter = createOpenRouter({
  apiKey: process.env.OPENROUTER_API_KEY!,
});

const sqlQuerySchema = z.object({
  query: z.string(),
  explanation: z.string(),
  isValid: z.boolean(),
  validationErrors: z.array(z.string()).optional(),
});

export const validateQuery = baseProcedure
  .input(z.object({ 
    naturalLanguageQuery: z.string().min(1, "Query cannot be empty")
  }))
  .mutation(async ({ input }) => {
    try {
      const { object } = await generateObject({
        model: openrouter("openai/gpt-4o"),
        schema: sqlQuerySchema,
        prompt: `You are a SQL expert for a customer database. Convert this natural language query to a secure SQL query.

Database Schema:
- customers: id, email, firstName, lastName, city, country, age, gender, phoneNumber, createdAt, updatedAt
- products: id, name, category, price, description, createdAt, updatedAt  
- purchases: id, customerId, productId, quantity, totalPrice, createdAt

Natural Language Query: "${input.naturalLanguageQuery}"

Requirements:
1. Generate a secure SQL SELECT query only (no INSERT, UPDATE, DELETE)
2. Use proper JOINs when needed
3. Validate the query for SQL injection risks
4. Explain what the query does
5. Set isValid to false if the query is unsafe or malformed

Return a JSON object with the SQL query, explanation, validation status, and any errors.`,
      });

      // Additional server-side validation
      const query = object.query.toLowerCase().trim();
      
      // Check for dangerous SQL keywords
      const dangerousKeywords = ['drop', 'delete', 'insert', 'update', 'alter', 'create', 'truncate', '--', ';'];
      const hasDangerousKeywords = dangerousKeywords.some(keyword => 
        query.includes(keyword.toLowerCase())
      );

      if (hasDangerousKeywords) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Query contains potentially dangerous SQL operations",
        });
      }

      if (!query.startsWith('select')) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Only SELECT queries are allowed",
        });
      }

      return {
        sqlQuery: object.query,
        explanation: object.explanation,
        isValid: object.isValid && !hasDangerousKeywords,
        validationErrors: object.validationErrors || [],
      };
    } catch (error) {
      console.error("Error in validateQuery:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to validate and generate SQL query",
      });
    }
  });
