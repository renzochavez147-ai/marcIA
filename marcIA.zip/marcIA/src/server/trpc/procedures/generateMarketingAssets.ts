import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { baseProcedure } from "~/server/trpc/main";
import { generateText } from "ai";
import { createOpenRouter } from "@openrouter/ai-sdk-provider";
import { minio, minioBaseUrl } from "~/server/minio";

const openrouter = createOpenRouter({
  apiKey: process.env.OPENROUTER_API_KEY!,
});

export const generateMarketingAssets = baseProcedure
  .input(z.object({
    customerData: z.array(z.record(z.any())),
    explanation: z.string(),
    campaignName: z.string().optional().default("Marketing Campaign")
  }))
  .mutation(async ({ input }) => {
    try {
      const { customerData, explanation, campaignName } = input;

      // Generate CSV content
      const csvContent = await generateCSV(customerData);
      
      // Store CSV in MinIO
      const csvFileName = `campaigns/${Date.now()}-${campaignName.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase()}.csv`;
      await minio.putObject('marketing-assets', csvFileName, csvContent, {
        'Content-Type': 'text/csv',
      });
      const csvUrl = `${minioBaseUrl}/marketing-assets/${csvFileName}`;

      // Generate HTML email template
      const { text: htmlEmail } = await generateText({
        model: openrouter("openai/gpt-4o"),
        system: "You are a professional email marketing specialist. Create engaging, personalized HTML email templates.",
        prompt: `Create a professional HTML email template for this marketing campaign.

Campaign Context: ${explanation}
Target Audience: ${customerData.length} customers
Sample Customer Data: ${JSON.stringify(customerData.slice(0, 3), null, 2)}

Requirements:
1. Create a complete HTML email template with inline CSS
2. Make it responsive and visually appealing
3. Include personalization placeholders like {{firstName}}, {{city}}, etc.
4. Add a clear call-to-action
5. Include professional branding elements
6. Make it engaging and conversion-focused

Return only the HTML code without any markdown formatting.`,
      });

      // Generate text summary
      const { text: textSummary } = await generateText({
        model: openrouter("openai/gpt-4o"),
        system: "You are a marketing analyst. Provide clear, actionable insights about customer segments.",
        prompt: `Analyze this customer segment and provide a marketing summary.

Query Context: ${explanation}
Customer Count: ${customerData.length}
Sample Data: ${JSON.stringify(customerData.slice(0, 5), null, 2)}

Provide a concise summary including:
1. Key demographic insights
2. Recommended marketing approach
3. Potential campaign themes
4. Expected engagement opportunities

Keep it under 200 words and actionable.`,
      });

      return {
        csvUrl,
        htmlEmail,
        textSummary,
        customerCount: customerData.length,
        generatedAt: new Date().toISOString(),
      };
    } catch (error) {
      console.error("Error generating marketing assets:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to generate marketing assets",
      });
    }
  });

async function generateCSV(data: Array<Record<string, any>>): Promise<string> {
  if (data.length === 0) {
    return "No data available";
  }

  // Get all unique keys from all objects
  const allKeys = Array.from(
    new Set(data.flatMap(obj => Object.keys(obj)))
  );

  // Create header row
  const header = allKeys.join(',');
  
  // Create data rows
  const rows = data.map(obj => 
    allKeys.map(key => {
      const value = obj[key];
      // Handle null/undefined values and escape commas/quotes
      if (value === null || value === undefined) return '';
      const stringValue = String(value);
      // Escape quotes and wrap in quotes if contains comma or quote
      if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }
      return stringValue;
    }).join(',')
  );

  return [header, ...rows].join('\n');
}
