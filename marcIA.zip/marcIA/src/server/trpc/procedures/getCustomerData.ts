import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const getCustomerData = baseProcedure
  .input(z.object({ 
    sqlQuery: z.string().min(1, "SQL query cannot be empty"),
    explanation: z.string()
  }))
  .query(async ({ input }) => {
    try {
      // Execute the validated SQL query using Prisma's raw query
      const results = await db.$queryRawUnsafe(input.sqlQuery);
      
      // Convert BigInt values to regular numbers for JSON serialization
      const serializedResults = JSON.parse(
        JSON.stringify(results, (key, value) =>
          typeof value === 'bigint' ? Number(value) : value
        )
      );

      return {
        data: serializedResults,
        explanation: input.explanation,
        recordCount: Array.isArray(serializedResults) ? serializedResults.length : 0,
        executedAt: new Date().toISOString(),
      };
    } catch (error) {
      console.error("Error executing SQL query:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to execute customer data query",
      });
    }
  });
