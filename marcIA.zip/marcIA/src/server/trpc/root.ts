import {
  createCallerFactory,
  createTRPCRouter,
  baseProcedure,
} from "~/server/trpc/main";
import { validateQuery } from "~/server/trpc/procedures/validateQuery";
import { getCustomerData } from "~/server/trpc/procedures/getCustomerData";
import { generateMarketingAssets } from "~/server/trpc/procedures/generateMarketingAssets";
import { getMinioBaseUrl } from "~/server/trpc/procedures/getMinioBaseUrl";

export const appRouter = createTRPCRouter({
  validateQuery,
  getCustomerData,
  generateMarketingAssets,
  getMinioBaseUrl,
});

export type AppRouter = typeof appRouter;

export const createCaller = createCallerFactory(appRouter);
