import { db } from "~/server/db";
import { minioClient } from "~/server/minio";

async function setup() {
  console.log("Setting up marcIA application...");
  
  // Create MinIO bucket for marketing assets
  try {
    const bucketExists = await minioClient.bucketExists('marketing-assets');
    if (!bucketExists) {
      await minioClient.makeBucket('marketing-assets');
      console.log("Created marketing-assets bucket");
      
      // Set bucket policy to allow public read access
      const policy = {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Principal: { AWS: ['*'] },
            Action: ['s3:GetObject'],
            Resource: ['arn:aws:s3:::marketing-assets/*']
          }
        ]
      };
      
      await minioClient.setBucketPolicy('marketing-assets', JSON.stringify(policy));
      console.log("Set public read policy for marketing-assets bucket");
    }
  } catch (error) {
    console.error("Error setting up MinIO bucket:", error);
  }

  // Seed database with sample data
  try {
    // Check if data already exists
    const customerCount = await db.customer.count();
    if (customerCount > 0) {
      console.log("Database already seeded, skipping...");
      return;
    }

    // Create sample products
    const products = await db.product.createMany({
      data: [
        {
          name: "Premium Coffee Beans",
          category: "Food & Beverage",
          price: 24.99,
          description: "High-quality arabica coffee beans from Colombia"
        },
        {
          name: "Wireless Headphones",
          category: "Electronics",
          price: 199.99,
          description: "Noise-canceling wireless headphones with premium sound"
        },
        {
          name: "Organic Skincare Set",
          category: "Beauty",
          price: 89.99,
          description: "Natural skincare products for daily routine"
        },
        {
          name: "Fitness Tracker",
          category: "Health & Fitness",
          price: 149.99,
          description: "Smart fitness tracker with heart rate monitoring"
        },
        {
          name: "Artisan Chocolate Box",
          category: "Food & Beverage",
          price: 34.99,
          description: "Handcrafted chocolate collection from local artisans"
        }
      ]
    });

    // Create sample customers
    const sampleCustomers = [
      { firstName: "Maria", lastName: "Rodriguez", email: "maria.rodriguez@email.com", city: "Lima", country: "Peru", age: 28, gender: "Female" },
      { firstName: "Carlos", lastName: "Mendoza", email: "carlos.mendoza@email.com", city: "Lima", country: "Peru", age: 35, gender: "Male" },
      { firstName: "Ana", lastName: "Silva", email: "ana.silva@email.com", city: "Cusco", country: "Peru", age: 42, gender: "Female" },
      { firstName: "Diego", lastName: "Torres", email: "diego.torres@email.com", city: "Arequipa", country: "Peru", age: 31, gender: "Male" },
      { firstName: "Sofia", lastName: "Vargas", email: "sofia.vargas@email.com", city: "Lima", country: "Peru", age: 26, gender: "Female" },
      { firstName: "Miguel", lastName: "Castillo", email: "miguel.castillo@email.com", city: "Trujillo", country: "Peru", age: 38, gender: "Male" },
      { firstName: "Isabella", lastName: "Morales", email: "isabella.morales@email.com", city: "Lima", country: "Peru", age: 29, gender: "Female" },
      { firstName: "Roberto", lastName: "Herrera", email: "roberto.herrera@email.com", city: "Chiclayo", country: "Peru", age: 45, gender: "Male" },
      { firstName: "Camila", lastName: "Jimenez", email: "camila.jimenez@email.com", city: "Lima", country: "Peru", age: 33, gender: "Female" },
      { firstName: "Fernando", lastName: "Gutierrez", email: "fernando.gutierrez@email.com", city: "Piura", country: "Peru", age: 27, gender: "Male" }
    ];

    for (const customerData of sampleCustomers) {
      await db.customer.create({
        data: customerData
      });
    }

    // Get created products and customers
    const createdProducts = await db.product.findMany();
    const createdCustomers = await db.customer.findMany();

    // Create sample purchases
    const purchasePromises = [];
    for (let i = 0; i < 25; i++) {
      const randomCustomer = createdCustomers[Math.floor(Math.random() * createdCustomers.length)];
      const randomProduct = createdProducts[Math.floor(Math.random() * createdProducts.length)];
      const quantity = Math.floor(Math.random() * 3) + 1;
      
      purchasePromises.push(
        db.purchase.create({
          data: {
            customerId: randomCustomer.id,
            productId: randomProduct.id,
            quantity,
            totalPrice: randomProduct.price * quantity,
            createdAt: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000) // Random date in last 90 days
          }
        })
      );
    }

    await Promise.all(purchasePromises);
    console.log("Database seeded with sample data");
    
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

setup()
  .then(() => {
    console.log("setup.ts complete");
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
