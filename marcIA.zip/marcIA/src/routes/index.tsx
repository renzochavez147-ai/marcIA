import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect, useCallback } from "react";
import { QueryForm } from "~/components/QueryForm";
import { ResultsDisplay } from "~/components/ResultsDisplay";
import { useTRPC } from "~/trpc/react";
import { useMutation, useQuery } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { Brain, Zap, Target, ArrowRight, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Home,
});

interface MarketingResults {
  customerData: Array<Record<string, any>>;
  explanation: string;
  csvUrl?: string;
  htmlEmail?: string;
  textSummary?: string;
  customerCount: number;
}

function Home() {
  const [currentStep, setCurrentStep] = useState<'input' | 'validating' | 'fetching' | 'generating' | 'results'>('input');
  const [validationResult, setValidationResult] = useState<{
    sqlQuery: string;
    explanation: string;
  } | null>(null);
  const [customerData, setCustomerData] = useState<Array<Record<string, any>>>([]);
  const [marketingResults, setMarketingResults] = useState<MarketingResults | null>(null);

  const trpc = useTRPC();

  // Validator Agent
  const validateMutation = useMutation(
    trpc.validateQuery.mutationOptions({
      onSuccess: (data) => {
        if (data.isValid) {
          setValidationResult({
            sqlQuery: data.sqlQuery,
            explanation: data.explanation
          });
          setCurrentStep('fetching');
          toast.success("Query validated successfully!");
        } else {
          toast.error("Invalid query: " + (data.validationErrors?.join(', ') || 'Unknown error'));
          setCurrentStep('input');
        }
      },
      onError: (error) => {
        toast.error("Validation failed: " + error.message);
        setCurrentStep('input');
      }
    })
  );

  // Data Agent - use proper query pattern with enabled flag
  const customerDataQuery = useQuery(
    trpc.getCustomerData.queryOptions(
      {
        sqlQuery: validationResult?.sqlQuery || '',
        explanation: validationResult?.explanation || ''
      },
      {
        enabled: currentStep === 'fetching' && !!validationResult,
        onSuccess: (data) => {
          setCustomerData(data.data);
          setCurrentStep('generating');
          toast.success(`Found ${data.recordCount} customers!`);
        },
        onError: (error: any) => {
          toast.error("Failed to fetch customer data: " + error.message);
          setCurrentStep('input');
        }
      }
    )
  );

  // Marketer Agent
  const generateAssetsMutation = useMutation(
    trpc.generateMarketingAssets.mutationOptions({
      onSuccess: (data) => {
        setMarketingResults({
          customerData,
          explanation: validationResult!.explanation,
          csvUrl: data.csvUrl,
          htmlEmail: data.htmlEmail,
          textSummary: data.textSummary,
          customerCount: data.customerCount
        });
        setCurrentStep('results');
        toast.success("Marketing assets generated successfully!");
      },
      onError: (error) => {
        toast.error("Failed to generate marketing assets: " + error.message);
        setCurrentStep('input');
      }
    })
  );

  // Handle form submission and workflow orchestration
  const handleQuerySubmit = useCallback(async (query: string) => {
    setCurrentStep('validating');
    toast.loading("Validating your query...", { id: 'workflow' });
    
    try {
      await validateMutation.mutateAsync({ naturalLanguageQuery: query });
    } catch (error) {
      // Error handling is done in the mutation callbacks
    }
  }, []); // Removed validateMutation from dependencies since mutateAsync is stable

  const handleStartOver = useCallback(() => {
    setCurrentStep('input');
    setValidationResult(null);
    setCustomerData([]);
    setMarketingResults(null);
    toast.dismiss('workflow');
  }, []);

  // Trigger asset generation when data fetching is complete and we have customer data
  useEffect(() => {
    if (currentStep === 'generating' && customerData.length > 0 && validationResult && !generateAssetsMutation.isPending) {
      toast.loading("Generating marketing assets...", { id: 'workflow' });
      generateAssetsMutation.mutate({
        customerData,
        explanation: validationResult.explanation,
        campaignName: "AI Marketing Campaign"
      });
    }
  }, [currentStep, customerData.length, validationResult, generateAssetsMutation.isPending, generateAssetsMutation.mutate]);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      {currentStep === 'input' && (
        <div className="relative overflow-hidden">
          {/* Background Image */}
          <div 
            className="absolute inset-0 z-0"
            style={{
              backgroundImage: "url('https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2574&q=80')",
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/90 via-purple-900/80 to-pink-900/90"></div>
          </div>

          {/* Hero Content */}
          <div className="relative z-10 px-4 py-20 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-7xl text-center">
              <div className="flex items-center justify-center mb-8">
                <div className="bg-white/10 rounded-full p-4 backdrop-blur-sm border border-white/20">
                  <Brain className="h-12 w-12 text-white" />
                </div>
              </div>
              
              <h1 className="text-6xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">
                  marcIA
                </span>
              </h1>
              
              <p className="text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
                AI-Powered Marketing Intelligence Platform
              </p>
              
              <p className="text-xl text-white/80 mb-12 max-w-4xl mx-auto">
                Transform natural language into targeted customer segments, automated email campaigns, and actionable marketing insights using advanced AI agents.
              </p>

              {/* Features */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 max-w-5xl mx-auto">
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                  <div className="bg-indigo-500 rounded-full p-3 w-fit mx-auto mb-4">
                    <Target className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Smart Targeting</h3>
                  <p className="text-white/80">Describe your ideal customers in plain English and let AI find them</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                  <div className="bg-purple-500 rounded-full p-3 w-fit mx-auto mb-4">
                    <Zap className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Instant Campaigns</h3>
                  <p className="text-white/80">Generate personalized email templates and customer lists automatically</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                  <div className="bg-pink-500 rounded-full p-3 w-fit mx-auto mb-4">
                    <Sparkles className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">AI Insights</h3>
                  <p className="text-white/80">Get actionable marketing recommendations based on customer data</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="relative z-10 px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          {/* Progress Indicator */}
          {currentStep !== 'input' && (
            <div className="mb-12">
              <div className="flex items-center justify-center space-x-4 mb-8">
                <div className={`flex items-center ${currentStep === 'validating' ? 'text-indigo-600' : 'text-green-600'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'validating' ? 'bg-indigo-100 border-2 border-indigo-600' : 'bg-green-100'}`}>
                    {currentStep === 'validating' ? (
                      <div className="w-3 h-3 bg-indigo-600 rounded-full animate-pulse"></div>
                    ) : (
                      <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                    )}
                  </div>
                  <span className="ml-2 font-medium">Validate</span>
                </div>
                
                <ArrowRight className="h-4 w-4 text-gray-400" />
                
                <div className={`flex items-center ${currentStep === 'fetching' ? 'text-indigo-600' : currentStep === 'generating' || currentStep === 'results' ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'fetching' ? 'bg-indigo-100 border-2 border-indigo-600' : currentStep === 'generating' || currentStep === 'results' ? 'bg-green-100' : 'bg-gray-100'}`}>
                    {currentStep === 'fetching' ? (
                      <div className="w-3 h-3 bg-indigo-600 rounded-full animate-pulse"></div>
                    ) : currentStep === 'generating' || currentStep === 'results' ? (
                      <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                    ) : (
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                    )}
                  </div>
                  <span className="ml-2 font-medium">Fetch Data</span>
                </div>
                
                <ArrowRight className="h-4 w-4 text-gray-400" />
                
                <div className={`flex items-center ${currentStep === 'generating' ? 'text-indigo-600' : currentStep === 'results' ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'generating' ? 'bg-indigo-100 border-2 border-indigo-600' : currentStep === 'results' ? 'bg-green-100' : 'bg-gray-100'}`}>
                    {currentStep === 'generating' ? (
                      <div className="w-3 h-3 bg-indigo-600 rounded-full animate-pulse"></div>
                    ) : currentStep === 'results' ? (
                      <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                    ) : (
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                    )}
                  </div>
                  <span className="ml-2 font-medium">Generate Assets</span>
                </div>
              </div>
            </div>
          )}

          {/* Query Form */}
          {currentStep === 'input' && (
            <QueryForm
              onSubmit={handleQuerySubmit}
              isLoading={validateMutation.isPending}
            />
          )}

          {/* Results Display */}
          {currentStep === 'results' && marketingResults && (
            <div className="space-y-8">
              <div className="text-center">
                <button
                  onClick={handleStartOver}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors duration-200"
                >
                  Create New Campaign
                </button>
              </div>
              
              <ResultsDisplay {...marketingResults} />
            </div>
          )}

          {/* Loading States */}
          {(currentStep === 'validating' || currentStep === 'fetching' || currentStep === 'generating') && (
            <div className="text-center py-20">
              <div className="bg-white rounded-3xl shadow-2xl p-12 max-w-2xl mx-auto">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto mb-8"></div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {currentStep === 'validating' && "AI Validator Agent Working..."}
                  {currentStep === 'fetching' && "Data Agent Retrieving Customers..."}
                  {currentStep === 'generating' && "Marketer Agent Creating Assets..."}
                </h3>
                <p className="text-gray-600 text-lg">
                  {currentStep === 'validating' && "Converting your query to secure SQL and validating the request"}
                  {currentStep === 'fetching' && "Executing database queries to find your target customers"}
                  {currentStep === 'generating' && "Generating personalized email templates, CSV files, and marketing insights"}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
