import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Sparkles, Target, Users } from "lucide-react";

const querySchema = z.object({
  query: z.string().min(10, "Please provide a more detailed query (at least 10 characters)"),
});

type QueryFormData = z.infer<typeof querySchema>;

interface QueryFormProps {
  onSubmit: (query: string) => void;
  isLoading: boolean;
}

export function QueryForm({ onSubmit, isLoading }: QueryFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<QueryFormData>({
    resolver: zodResolver(querySchema),
  });

  const handleFormSubmit = (data: QueryFormData) => {
    onSubmit(data.query);
    reset();
  };

  const exampleQueries = [
    "Show me customers in Lima who bought electronics in the last month",
    "Find female customers aged 25-35 who purchased beauty products",
    "Get customers from Peru who spent more than $100 on food items",
  ];

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 px-8 py-12 text-white">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-white/20 rounded-full p-4 backdrop-blur-sm">
              <Sparkles className="h-8 w-8" />
            </div>
          </div>
          <h2 className="text-4xl font-bold text-center mb-4">
            Define Your Target Audience
          </h2>
          <p className="text-xl text-center text-white/90 max-w-2xl mx-auto">
            Describe your ideal customer segment in natural language. Our AI will find them and create personalized campaigns.
          </p>
        </div>

        {/* Form content */}
        <div className="px-8 py-12">
          <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-8">
            <div>
              <label
                htmlFor="query"
                className="block text-lg font-semibold text-gray-800 mb-4"
              >
                Describe your target customers
              </label>
              <div className="relative">
                <textarea
                  id="query"
                  rows={4}
                  placeholder="e.g., I want to target customers in Lima who bought premium coffee in the last 30 days..."
                  {...register("query")}
                  className="w-full px-6 py-4 text-lg border-2 border-gray-200 rounded-2xl focus:border-indigo-500 focus:ring-0 transition-colors duration-200 resize-none placeholder-gray-400"
                />
                <div className="absolute bottom-4 right-4">
                  <Target className="h-6 w-6 text-gray-300" />
                </div>
              </div>
              {errors.query && (
                <p className="mt-3 text-red-600 font-medium">{errors.query.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 text-white font-bold py-6 px-8 rounded-2xl text-xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 shadow-lg hover:shadow-xl disabled:shadow-md"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mr-3"></div>
                  Analyzing Your Audience...
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <Users className="h-6 w-6 mr-3" />
                  Find My Customers
                </div>
              )}
            </button>
          </form>

          {/* Example queries */}
          <div className="mt-12">
            <h3 className="text-lg font-semibold text-gray-800 mb-6 text-center">
              Try these examples:
            </h3>
            <div className="grid gap-4 md:grid-cols-1 lg:grid-cols-3">
              {exampleQueries.map((example, index) => (
                <button
                  key={index}
                  onClick={() => {
                    const form = document.getElementById('query') as HTMLTextAreaElement;
                    if (form) form.value = example;
                  }}
                  className="p-4 bg-gray-50 hover:bg-gray-100 rounded-xl text-left text-sm text-gray-700 transition-colors duration-200 border border-gray-200 hover:border-gray-300"
                >
                  "{example}"
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
