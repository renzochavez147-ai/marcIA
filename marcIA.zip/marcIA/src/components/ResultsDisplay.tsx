import { Download, Mail, FileText, Users, TrendingUp, Eye } from "lucide-react";

interface Customer {
  [key: string]: any;
}

interface ResultsDisplayProps {
  customerData: Customer[];
  explanation: string;
  csvUrl?: string;
  htmlEmail?: string;
  textSummary?: string;
  customerCount: number;
}

export function ResultsDisplay({
  customerData,
  explanation,
  csvUrl,
  htmlEmail,
  textSummary,
  customerCount,
}: ResultsDisplayProps) {
  const handleEmailPreview = () => {
    if (!htmlEmail) return;
    
    const previewWindow = window.open('', '_blank');
    if (previewWindow) {
      previewWindow.document.write(htmlEmail);
      previewWindow.document.close();
    }
  };

  // Get sample customer data for preview
  const sampleCustomers = customerData.slice(0, 5);
  const customerKeys = customerData.length > 0 ? Object.keys(customerData[0]) : [];

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-6 border border-blue-200">
          <div className="flex items-center">
            <div className="bg-blue-500 rounded-full p-3 mr-4">
              <Users className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-blue-600">Target Customers</p>
              <p className="text-3xl font-bold text-blue-900">{customerCount.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl p-6 border border-green-200">
          <div className="flex items-center">
            <div className="bg-green-500 rounded-full p-3 mr-4">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-green-600">Campaign Ready</p>
              <p className="text-3xl font-bold text-green-900">100%</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-violet-100 rounded-2xl p-6 border border-purple-200">
          <div className="flex items-center">
            <div className="bg-purple-500 rounded-full p-3 mr-4">
              <Mail className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-purple-600">Assets Generated</p>
              <p className="text-3xl font-bold text-purple-900">3</p>
            </div>
          </div>
        </div>
      </div>

      {/* Query Explanation */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Campaign Overview</h3>
        <p className="text-lg text-gray-700 leading-relaxed">{explanation}</p>
      </div>

      {/* Customer Data Preview */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-gray-900">Customer Preview</h3>
          <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full font-medium">
            {customerCount} customers found
          </span>
        </div>
        
        {sampleCustomers.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  {customerKeys.slice(0, 6).map((key) => (
                    <th key={key} className="text-left py-3 px-4 font-semibold text-gray-700 capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sampleCustomers.map((customer, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                    {customerKeys.slice(0, 6).map((key) => (
                      <td key={key} className="py-3 px-4 text-gray-600">
                        {customer[key]?.toString() || 'N/A'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Marketing Assets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* CSV Download */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
          <div className="flex items-center mb-6">
            <div className="bg-green-500 rounded-full p-3 mr-4">
              <Download className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">Customer List</h3>
          </div>
          <p className="text-gray-600 mb-6">
            Download the complete customer list as a CSV file for your CRM or email platform.
          </p>
          {csvUrl && (
            <a
              href={csvUrl}
              download
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-xl transition-colors duration-200 flex items-center justify-center"
            >
              <Download className="h-5 w-5 mr-2" />
              Download CSV
            </a>
          )}
        </div>

        {/* Email Template */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
          <div className="flex items-center mb-6">
            <div className="bg-blue-500 rounded-full p-3 mr-4">
              <Mail className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">Email Template</h3>
          </div>
          <p className="text-gray-600 mb-6">
            AI-generated HTML email template personalized for your target audience.
          </p>
          {htmlEmail && (
            <button
              onClick={handleEmailPreview}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-xl transition-colors duration-200 flex items-center justify-center"
            >
              <Eye className="h-5 w-5 mr-2" />
              Preview Email
            </button>
          )}
        </div>

        {/* Marketing Summary */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
          <div className="flex items-center mb-6">
            <div className="bg-purple-500 rounded-full p-3 mr-4">
              <FileText className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">Campaign Insights</h3>
          </div>
          {textSummary && (
            <div className="text-gray-700 leading-relaxed">
              {textSummary.split('\n').map((paragraph, index) => (
                <p key={index} className="mb-3">
                  {paragraph}
                </p>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
